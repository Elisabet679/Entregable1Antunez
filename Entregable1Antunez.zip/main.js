// Valor constante 
const precioUnitario = 50;  
// Stock de Colores
let colores = ["amarillas", "rojas", "azules"];
// Cantidad de flores a adquirir
function pedirCantidad() {
    let cantidad;
    let valido = false;  

    while (!valido) {
        cantidad = parseInt(prompt("Ingrese la cantidad de flores que desea comprar:"));

        if (!isNaN(cantidad) && cantidad > 0) { //  
            valido = true;  
        } else {
            alert("Debe ingresar un número válido mayor o igual a 1.");
        }
    }

    return cantidad;
}

// Seleccionar el color
function pedirColor() {
    let color;

    while (true) {
        color = prompt("Ingrese el color de la flor que desea (amarillas, rojas o azules):");
 
        if (color === null) {
            alert("Debe seleccionar un color válido.");
            continue;
        }

        color = color.toLowerCase().trim();

        if (colores.includes(color)) {
            return color; 
        } else {
            alert("Ese color no está disponible. Intente de nuevo.");
        }
    }
}

// Valor total de la compra
function calcularPrecio(cantidad) {
    return cantidad * precioUnitario;
}

// Valor final
function mostrarResultado(cantidad, color, total) {
    alert("Compraste " + cantidad + " flores " + color + ".\nEl precio total es $" + total);
    console.log("Cantidad: " + cantidad + " | Color: " + color + " | Total: $" + total);
}

 
function simulador() {
    alert("Bienvenido al simulador de venta de flores 🌹");

    console.log("Colores disponibles: " + colores.join(", "));

    let seguir = true;

    while (seguir) {
        let cantidad = pedirCantidad();
        if (cantidad) {
            let color = pedirColor();
            let total = calcularPrecio(cantidad);
            mostrarResultado(cantidad, color, total);
        }
        seguir = confirm("¿Desea comprar más flores?");
    }
    alert("Gracias por su compra!");
}

// Ejecutar el simulador
simulador();